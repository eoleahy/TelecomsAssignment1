/**
 * 
 */
package cs.tcd.ie;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;

import java.util.Random;

import tcdIO.*;

/**
 *
 * Client class
 * 
 * An instance accepts user input
 *
 */
public class Client extends Node {
	static final int GATEWAY_PORT = 40789;
	static final int MAX_CLIENT_PORT = 40000;
	static final int MIN_CLIENT_PORT = 1024;
	static final String DEFAULT_DST_NODE = "localhost";

	Terminal terminal;
	InetSocketAddress gatewayAddress;
	int sequenceNumber = 0;
	String payloadString;
	DatagramPacket packetToSend;

	/**
	 * Constructor
	 * 
	 * Attempts to create socket at given port and create an InetSocketAddress
	 * for the destinations
	 */
	Client(Terminal terminal, String dstHost, int dstPort, int srcPort) {
		try {
			this.terminal = terminal;
			gatewayAddress = new InetSocketAddress(dstHost, dstPort);

			socket = new DatagramSocket(srcPort);
			terminal.println("Port number = " + Integer.toString(srcPort));
			listener.go();
		} catch (java.net.BindException exception) {
			Random rand = new Random();
			srcPort = rand.nextInt(MAX_CLIENT_PORT-MIN_CLIENT_PORT) + MIN_CLIENT_PORT;
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 * 
	 * @throws Exception
	 */
	public synchronized void onReceipt(DatagramPacket packet) throws Exception {
		socket.setSoTimeout(0);
		String incomingMessage = extractMessage(packet);
		String expectedACK = "ACK " + (sequenceNumber + 1);

		/*
		 *  The following code handles the situation where the client for some
		 *  reason receives the incorrect ACK.
		 */
		if (expectedACK.equals(incomingMessage)) {
			sequenceNumber++;
		} else {
			terminal.println("Incorrect sequence number, resending packet");
			sequenceNumber--;
			socket.send(packetToSend);
		}
		this.notify();
		terminal.println(incomingMessage);
	}

	/**
	 * Sender Method
	 * 
	 */
	public synchronized void start() throws Exception {

		byte[] payload = null;
		byte[] header = null;
		byte[] buffer = null;

		payloadString = terminal.readString("String to send: ");
		if (payloadString.equals("exit")) {
			System.exit(0);
		}
		payloadString = payloadString + SPLITTER + 0 + SPLITTER + sequenceNumber;

		payload = payloadString.getBytes();
		header = new byte[PacketContent.HEADERLENGTH];
		buffer = new byte[header.length + payload.length];

		System.arraycopy(header, 0, buffer, 0, header.length);
		System.arraycopy(payload, 0, buffer, header.length, payload.length);

		try {
			packetToSend = new DatagramPacket(buffer, buffer.length, gatewayAddress);

			socket.send(packetToSend);
			socket.setSoTimeout(5000);
			terminal.println("Packet sent");
			this.wait();
		} catch (java.net.SocketTimeoutException exception) {
			terminal.println("Resending packet...");
			socket.send(packetToSend);
			socket.setSoTimeout(5000);
		}
	}

	/**
	 * Test method
	 * 
	 * Sends a packet to a given address
	 */
	public static void main(String[] args) {
		try {
			Terminal terminal = new Terminal("Client");
			Random rand = new Random();
			int srcPort = rand.nextInt(MAX_CLIENT_PORT-MIN_CLIENT_PORT) + MIN_CLIENT_PORT;

			Client client = (new Client(terminal, DEFAULT_DST_NODE, GATEWAY_PORT, srcPort));
			boolean running = true;
			while (running) {
				client.start();
			}
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}
}
