package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.concurrent.CountDownLatch;

public abstract class Node {
	static final int PACKETSIZE = 65536;
	static final String SPLITTER= ";;;";

	DatagramSocket socket;
	Listener listener;
	CountDownLatch latch;
	
	Node() {
		latch= new CountDownLatch(1);
		listener= new Listener();
		listener.setDaemon(true);
		listener.start();
	}
	
	
	public abstract void onReceipt(DatagramPacket packet) throws Exception;
	
	/**
	 *
	 * Listener thread
	 * 
	 * Listens for incoming packets on a datagram socket and informs registered receivers about incoming packets.
	 */
	class Listener extends Thread {
		
		/*
		 *  Telling the listener that the socket has been initialized 
		 */
		public void go() {
			latch.countDown();
		}
		
		/*
		 * Listen for incoming packets and inform receivers
		 */
		public void run() {
			try {
				latch.await();
				// Endless loop: attempt to receive packet, notify receivers, etc
				while(true) {
					DatagramPacket packet = new DatagramPacket(new byte[PACKETSIZE], PACKETSIZE);
					socket.receive(packet);

					onReceipt(packet);
				}
			} catch (Exception e) {if (!(e instanceof SocketException)) e.printStackTrace();}
		}
	}
	/*		
	 * 		A method which can extract the payload (or message) which is 
	 * 		encapsulated inside a packet assuming the correct layout is
	 * 		met. This is done by splitting the buffer of an incoming
	 * 		packet into an array of strings and returning the relevant
	 * 		data.
	 * 
	 * 		@param DatagramPacket packet -  the packet from which you want
	 * 		to extract the encapsulated message
	 * 		  
	 * 		@return - the encapsulated message string
	 */		
		public static String extractMessage(DatagramPacket packet) {
			StringContent content = new StringContent(packet);
			String packetContent = content.toString();
			String[] packetContentArray = packetContent.split(SPLITTER);
			return packetContentArray[0];
		}
	/*		
	 * 		A method which can extract the port which is encapsulated
	 * 		inside a packet assuming the correct layout is met.
	 * 
	 * 		@param DatagramPacket packet -  the packet from which you want
	 * 		to extract the encapsulated address
	 * 
	 * 		@return - the port number
	 */
		public static int extractPort(DatagramPacket packet) {
			int extractedPort = 0;
			StringContent content = new StringContent(packet);
			String packetContent = content.toString();
			String[] packetContentArray = packetContent.split(SPLITTER);
			extractedPort = Integer.parseInt(packetContentArray[1]);
			return extractedPort;
		}
	/*		
	 * 		A method which can extract the sequence number
	 * 		of a particular client. which is encapsulated
	 * 		inside a packet assuming the correct layout is met.
	 * 
	 * 		@param DatagramPacket packet -  the packet from which you want
	 * 		to extract the encapsulated address
	 * 		  
	 * 		@return - the sequence number
	 */			
		public static int extractSequenceNumber(DatagramPacket packet) {
			int extractedSequence;
			StringContent content = new StringContent(packet);
			String packetContent = content.toString();
			String[] packetContentArray = packetContent.split(SPLITTER);
			extractedSequence = Integer.parseInt(packetContentArray[2]);			
			return extractedSequence;
		}
}
