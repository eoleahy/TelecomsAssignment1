package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.HashMap;

import tcdIO.Terminal;

public class Server extends Node {
	static final int DEFAULT_PORT = 50001;

	Terminal terminal;
	String responseMessage;
	int expectedSequenceNumber = 0;
	HashMap<Integer, Integer> sequenceList = new HashMap<Integer, Integer>();

	/*
	 * 
	 */
	Server(Terminal terminal, int serverPort) {
		try {

			this.terminal = terminal;
			socket = new DatagramSocket(serverPort);
			listener.go();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public void onReceipt(DatagramPacket packet) {
		try {
			// Breaks up the elements of the incoming packet buffer and prints
			// the incoming message .

			int clientPort = extractPort(packet);
			String message = extractMessage(packet);
			int incomingSequenceNumber = extractSequenceNumber(packet);

			terminal.println("Incoming message from " + Integer.toString(clientPort) + ": " + message);

			/**
			 * The following code checks and updates a hashmap containing the
			 * client's port and the corresponding sequence number for that
			 * client(provided the sequence number is correct). This ensures
			 * that the correct ACK is sent to the correct client.
			 */
			if (!sequenceList.containsKey(clientPort) && (incomingSequenceNumber == 0)) {
				expectedSequenceNumber = 0;
				sequenceList.put(clientPort, expectedSequenceNumber);
			}

			int tempSeqeunceNumber = sequenceList.get(clientPort);
			expectedSequenceNumber = tempSeqeunceNumber;

			if (incomingSequenceNumber != expectedSequenceNumber) { //Incorrect sequence number
				 terminal.println("Incorrect sequence number, please re-send packet");
				 responseMessage =("NAK");
			} else {	//Correct sequence number
				responseMessage = "ACK " + Integer.toString(++tempSeqeunceNumber);
				sequenceList.put(clientPort, tempSeqeunceNumber);
			}
			// Creates a response to be sent to the client
			DatagramPacket response;
			response = (new StringContent(responseMessage + SPLITTER + clientPort + SPLITTER + 0)).toDatagramPacket();
			response.setSocketAddress(packet.getSocketAddress());
			socket.send(response);
			terminal.println("Response sent");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void start() throws Exception {
		terminal.println("Waiting for contact");
		this.wait();
	}

	/*
	 * 
	 */
	public static void main(String[] args) {
		try {
			Terminal terminal = new Terminal("Server");
			(new Server(terminal, DEFAULT_PORT)).start();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

}
