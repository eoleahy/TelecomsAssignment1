package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

import tcdIO.Terminal;

public class Gateway extends Node {
	static final int GATEWAY_PORT = 40789;
	static final int SERVER_PORT = 50001;
	static final String DST_NODE = "localhost";

	Terminal terminal;
	InetSocketAddress serverAddress;

	/*
	 * 
	 */
	Gateway(Terminal terminal, String serverHost, int gatewayPort, int dstPort) {
		try {
			this.terminal = terminal;
			serverAddress = new InetSocketAddress(serverHost, dstPort);
			socket = new DatagramSocket(gatewayPort);
			listener.go();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public void onReceipt(DatagramPacket packet) {
		try {

			int incomingPortNumber = packet.getPort();
			/*
			 * The following checks if the incoming packet is coming from the server or a client.
			 * In the case of it being from the server the Gateway will forward it on to the corresponding
			 * client. 
			 * If the packet is from a client it will be forwarded on to the Server
			 * 
			 */
			if (incomingPortNumber == SERVER_PORT) { // Send a response to client from server
				terminal.println("Incoming packet from Server");
				InetSocketAddress clientAddress = new InetSocketAddress(DST_NODE, extractPort(packet));
				DatagramPacket responsePacket = new StringContent(extractMessage(packet)
						+ SPLITTER + extractPort(packet) + SPLITTER + 0).toDatagramPacket();
				responsePacket.setSocketAddress(clientAddress);
				socket.send(responsePacket);
				terminal.println("Response sent to Client...");

			} else { // Send message to server from client
				terminal.println("Incoming packet from " + Integer.toString(incomingPortNumber));
				StringContent payloadString = new StringContent(extractMessage(packet) + SPLITTER
						+ Integer.toString(incomingPortNumber) + SPLITTER + extractSequenceNumber(packet));
				DatagramPacket packetToSendToServer = payloadString.toDatagramPacket();
				packetToSendToServer.setSocketAddress(serverAddress);
				socket.send(packetToSendToServer);
				terminal.println("Packet sent to server...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void start() throws Exception {
		terminal.println("Awaiting incoming packets...");
		this.wait();

	}

	/*
	 * 
	 */
	public static void main(String[] args) {
		try {
			Terminal terminal = new Terminal("Gateway");
			(new Gateway(terminal, DST_NODE, GATEWAY_PORT, SERVER_PORT)).start();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

}
